export default {
  minW: 5, //绘制最小宽度
  minH: 5, //绘制最小高度
  minGapH: 5, //水平最小合并高度
  minGapW: 5, //水平最小合并宽度
  defaultColor: "#f4f4f4", //默认背景色
  defaultBg:"#f4f4f4",//整块的默认背景色
  borderRaduis:'4px'
}; 
