const { getESLintConfig } = require('@iceworks/spec');

module.exports = getESLintConfig('react-ts', { 
  env: {
    jest: true
  },
});
