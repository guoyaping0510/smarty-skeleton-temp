import React from 'react';
import { shallow } from 'enzyme';
import SmartySkeletonReactLoading from '../src/index';
import '../src/main.scss';

it('renders', () => {
  const wrapper = shallow(<SmartySkeletonReactLoading />);
  expect(wrapper.find('.smarty-skeleton-react-loading').length).toBe(1);
});
