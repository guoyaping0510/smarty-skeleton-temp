module.exports = {
  setupFilesAfterEnv: ['<rootDir>/test/setupTests.js'],
};
