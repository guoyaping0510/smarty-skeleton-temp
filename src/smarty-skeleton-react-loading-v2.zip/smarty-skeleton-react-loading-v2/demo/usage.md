---
title: Simple Usage
order: 1
---

本 Demo 演示一行文字的用法。

```jsx
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import SmartySkeletonReactLoading from '@ali/smarty-skeleton-react-loading-v2';

class App extends Component {
  render() {
    return (
      <div>
        <SmartySkeletonReactLoading  loading={false} id='test' >
        测试
        </SmartySkeletonReactLoading>
      </div>
    );
  }
}

ReactDOM.render((
  <App />
), mountNode);
```
