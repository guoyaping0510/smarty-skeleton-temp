const { getStylelintConfig } = require('@iceworks/spec');

module.exports = getStylelintConfig('react');
